const StudentValidateForm = () => {
  return(
    <></>
  );
}

export default StudentValidateForm;