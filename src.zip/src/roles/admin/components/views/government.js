const Government = ({ application }) => {
  return(
    <>
      <div className="popup-overlay">
        <div className="entrance-application">
          Government
        </div>
      </div>
    </>
  );
}

export default Government;