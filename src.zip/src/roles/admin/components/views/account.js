const ViewAccount = () => {
  return(
    <></>
  );
}

export default ViewAccount;