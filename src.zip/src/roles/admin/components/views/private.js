const Private = ({ application }) => {
  return(
    <>
      <div className="popup-overlay">
        <div className="entrance-application">
          Private
        </div>
      </div>
    </>
  );
}

export default Private