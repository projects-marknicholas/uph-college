const StudentAssistantship = ({ application }) => {
  return(
    <>
      <div className="popup-overlay">
        <div className="entrance-application">
          StudentAssistantship
        </div>
      </div>
    </>
  );
}

export default StudentAssistantship;