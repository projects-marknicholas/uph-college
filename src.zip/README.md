## Step 1: 

download ```nodejs``` in this link ```https://nodejs.org/en/download/prebuilt-installer``` if you don't have one

## Step 2:

```git clone https://github.com/projects-marknicholas/uph-college``` using git in your desired folder, install git if you don't have one.

## Step 3:

open the cmd of the path and type ```npm install``` to install all required modules.

## Step 4:

```npm start``` to run the project
